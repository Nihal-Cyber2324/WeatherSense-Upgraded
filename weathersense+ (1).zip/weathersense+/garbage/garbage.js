// ✅ Garbage.js - Waste Identification using TensorFlow.js Local Model (Teachable Machine)

let model;

// Load Teachable Machine Model (Updated with shared model URL)
const modelURL = "https://teachablemachine.withgoogle.com/models/5Gu1ZqkM3/";

async function loadModel() {
  model = await tmImage.load(modelURL + "model.json", modelURL + "metadata.json");
  console.log("✅ Local Model Loaded Successfully");
}

loadModel();

// Predict from uploaded image
async function predictImage() {
  const file = document.getElementById("imageUpload").files[0];
  if (!file) return;

  const img = new Image();
  img.src = URL.createObjectURL(file);
  img.onload = async () => {
    const predictions = await model.predict(img);
    const topResult = predictions.reduce((prev, current) => (prev.probability > current.probability) ? prev : current);
    displayPrediction(topResult.className);
  };
}

// Camera capture functionality
let cameraStream;

async function startCamera() {
  const cameraView = document.getElementById("cameraView");
  const captureBtn = document.getElementById("captureBtn");

  cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
  cameraView.srcObject = cameraStream;

  cameraView.classList.remove("hidden");
  captureBtn.classList.remove("hidden");
}

async function capturePhoto() {
  const canvas = document.getElementById("canvas");
  const cameraView = document.getElementById("cameraView");
  const context = canvas.getContext("2d");

  canvas.width = cameraView.videoWidth;
  canvas.height = cameraView.videoHeight;

  context.drawImage(cameraView, 0, 0, canvas.width, canvas.height);

  const img = new Image();
  img.src = canvas.toDataURL("image/png");

  img.onload = async () => {
    const predictions = await model.predict(img);
    const topResult = predictions.reduce((prev, current) => (prev.probability > current.probability) ? prev : current);
    displayPrediction(topResult.className);
  };
}

// Waste classification mapping
function getWasteInfo(objectName) {
  const data = {
    "Plastic Bottle": {
      type: "Non-Biodegradable",
      impact: "Takes 450+ years to decompose, harms marine life.",
      tip: "Use a reusable water bottle made of steel or glass."
    },
    "Banana Peel": {
      type: "Biodegradable",
      impact: "Decomposes naturally, great for composting.",
      tip: "Compost it in your home compost bin."
    },
    "Paper": {
      type: "Recyclable",
      impact: "Can be recycled to save trees and reduce landfill waste.",
      tip: "Recycle clean paper and reuse scrap sheets."
    },
    "Plastic Bag": {
      type: "Non-Biodegradable",
      impact: "Pollutes the environment and takes centuries to break down.",
      tip: "Switch to cloth bags for shopping."
    },
    "Aluminum Can": {
      type: "Recyclable",
      impact: "Easily recyclable, but energy intensive to produce.",
      tip: "Recycle cans properly at your local center."
    }
  };

  return data[objectName] || {
    type: "Unknown",
    impact: "No data available.",
    tip: "Try using another common household waste item."
  };
}

// Display the prediction result
function displayPrediction(objectName) {
  const { type, impact, tip } = getWasteInfo(objectName);
  document.getElementById("detectedObject").textContent = objectName;
  document.getElementById("wasteType").textContent = type;
  document.getElementById("ecoImpact").innerHTML = impact;
  document.getElementById("ecoTip").textContent = tip;
}
