const apiKey = "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";

async function getFarmerAdvice() {
  const cityInput = document.getElementById("cityInput");
  const cropInput = document.getElementById("cropInput");
  const adviceGrid = document.getElementById("adviceGrid");

  adviceGrid.innerHTML = "";

  const city = cityInput.value.trim();
  const crop = cropInput.value.trim();

  if (!city || !crop) {
    alert("Please enter both city and crop.");
    return;
  }

  addAdviceCard("⏳ Loading", "Fetching AI-powered advisory...");

  try {
    const advice = await fetchGenAIAdvisory(city, crop);
    adviceGrid.innerHTML = ""; // Clear loading

    addAdviceCard("🌤️ Weather Insight", advice.weatherInsight);
    addAdviceCard("💧 Irrigation Tip", advice.irrigation);
    addAdviceCard("🐞 Pest Alert", advice.pestAlert);
    addAdviceCard("🌱 Crop Advice", advice.cropAdvice);
    addAdviceCard("🌍 Soil Insight", advice.soilInsight);
    addAdviceCard("📈 Market Price Demand", advice.marketDemand);
  } catch (err) {
    adviceGrid.innerHTML = "";
    addAdviceCard("❌ Error", err.message || "Something went wrong.");
  }
}

async function fetchGenAIAdvisory(city, crop) {
  const prompt = `You're an Indian agricultural expert. Given:
City: ${city}
Crop: ${crop}

Write detailed farmer advisory in 6 sections (around 100–150 words each):
1. Weather Insight
2. Irrigation Tip
3. Pest Alert
4. Crop Advice
5. Soil Insight
6. Market Price Demand

Use section titles exactly as written. Make the content practical, India-specific, and easy to understand for farmers.`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are a helpful agricultural advisory assistant. Reply in 6 clearly labeled sections.",
          },
          { role: "user", content: prompt },
        ],
        max_tokens: 1200,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error?.message || "OpenAI API error.");
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "No response.";

    // Clean and extract sections
    const cleanText = content
      .replace(/###\s*\d+\.\s*/g, '')         // remove markdown headings like "### 1."
      .replace(/\*\*(.*?)\*\*/g, '$1')        // remove bold markdown
      .trim();

    const parts = cleanText
      .split(/(?=Weather Insight|Irrigation Tip|Pest Alert|Crop Advice|Soil Insight|Market Price Demand)/)
      .map(p => p.trim());

    return {
      weatherInsight: parts.find(p => p.startsWith("Weather Insight"))?.replace("Weather Insight", "").trim() || "No weather data.",
      irrigation: parts.find(p => p.startsWith("Irrigation Tip"))?.replace("Irrigation Tip", "").trim() || "No irrigation advice.",
      pestAlert: parts.find(p => p.startsWith("Pest Alert"))?.replace("Pest Alert", "").trim() || "No pest alert.",
      cropAdvice: parts.find(p => p.startsWith("Crop Advice"))?.replace("Crop Advice", "").trim() || "No crop advice.",
      soilInsight: parts.find(p => p.startsWith("Soil Insight"))?.replace("Soil Insight", "").trim() || "No soil insight.",
      marketDemand: parts.find(p => p.startsWith("Market Price Demand"))?.replace("Market Price Demand", "").trim() || "No market insight."
    };
  } catch (error) {
    console.error("OpenAI Error:", error);
    throw new Error("Failed to get advisory from AI.");
  }
}

function addAdviceCard(title, text) {
  const card = document.createElement("div");
  card.className = "advice-card";
  card.innerHTML = `<h3>${title}</h3><p>${text}</p>`;
  document.getElementById("adviceGrid").appendChild(card);
}
