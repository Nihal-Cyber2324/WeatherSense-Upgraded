const apiKey = "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";  // Replace with your actual API key
function formatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")           // bold
    .replace(/\\n/g, "<br>")                                     // new lines
    .replace(/(?:\\n)?(\\d+\\. )/g, "<br><strong>$1</strong>")   // numbered list
    .replace(/\\n\\n/g, "<br><br>");                             // double newlines
}

function addAdviceCard(title, text, containerId) {
  const card = document.createElement("div");
  card.className = "advice-card";
  card.innerHTML = `<h3>${title}</h3><p>${formatText(text)}</p>`;
  document.getElementById(containerId).appendChild(card);
}

async function fetchClimateAdvice(prompt, containerId, title) {
  try {
    document.getElementById(containerId).innerHTML = "";
    addAdviceCard("⏳ Loading...", "Please wait while we fetch suggestions...", containerId);

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are a friendly environmental advisor helping 17–19 year old students understand their climate impact. Provide tips in a fun, simple, and helpful tone."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 600,
        temperature: 0.6
      })
    });

    const data = await response.json();
    const result = data.choices?.[0]?.message?.content || "No advice returned.";
    document.getElementById(containerId).innerHTML = "";
    addAdviceCard(title, result, containerId);
  } catch (err) {
    document.getElementById(containerId).innerHTML = "";
    addAdviceCard("❌ Error", "Something went wrong. Try again later.", containerId);
    console.error("OpenAI Error:", err);
  }
}

// === User Input Handlers ===

function calculateCarbon() {
  const km = document.getElementById("carbonKm").value.trim();
  const mode = document.getElementById("carbonMode").value;
  const container = "carbonAdvice";

  if (!km || isNaN(km)) {
    alert("Please enter a valid distance.");
    return;
  }

  const prompt = `A User(Student) travels ${km} km daily using ${mode}. Give an engaging explanation of the carbon impact of this choice and 3 fun, easy alternatives they can try. Format clearly with bold titles and short paragraphs.`;

  fetchClimateAdvice(prompt, container, "🌫️ Carbon Footprint Advice");
}

function calculateWater() {
  const shower = document.getElementById("showerMinutes").value.trim();
  const flushes = document.getElementById("toiletFlushes").value.trim();
  const laundry = document.getElementById("washingLoads").value.trim();
  const container = "waterAdvice";

  if (!shower || !flushes || !laundry) {
    alert("Please fill in all water input fields.");
    return;
  }

  const prompt = `A User(Student) takes ${shower} min showers, flushes the toilet ${flushes} times per day, and uses the washing machine ${laundry} times per week. Provide simple, actionable water-saving tips in 3 sections, formatted with bold headings and bullet points if needed.`;

  fetchClimateAdvice(prompt, container, "💧 Water Saving Advice");
}

function calculateEnergy() {
  const fan = document.getElementById("fanHours").value.trim();
  const bulbs = document.getElementById("bulbHours").value.trim();
  const device = document.getElementById("deviceHours").value.trim();
  const container = "energyAdvice";

  if (!fan || !bulbs || !device) {
    alert("Please complete all energy fields.");
    return;
  }

  const prompt = `A User(Student) uses a fan for ${fan} hrs/day, light bulbs for ${bulbs} hrs/day, and electronics like TV or laptop for ${device} hrs/day. Explain how much energy this could use and suggest 3 ways to reduce it. Format clearly with short sections and bold text.`;

  fetchClimateAdvice(prompt, container, "⚡ Energy Saving Advice");
}
