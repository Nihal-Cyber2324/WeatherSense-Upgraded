// WeatherSense+ Final Script
const openWeatherKey = '4a34142e740b8484c773427a69950549';
const openUV = "openuv-2gdn2rmc37cqof-io";

let Globe;
const globeMarkers = [];
let globeGroup = new THREE.Group();
let camera;
let controls;
let aqiValueGlobal = 0;

// Start the App after welcome
function startApp() {
    document.getElementById('welcomeScreen').style.display = 'none';
    document.getElementById('appContainer').style.display = 'flex'; // Main layout is flex now
    window.scrollTo({ top: 0, behavior: 'smooth' });
    initGlobe();
}

// Search and fetch weather
function searchWeather() {
    const city = document.getElementById('cityInput').value;
    if (!city) return alert('Please enter a city!');
    fetchWeather(city);
}

// Main weather fetch
async function fetchWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${openWeatherKey}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod !== "200") {
        alert('City not found!');
        return;
    }

    const lat = data.city.coord.lat;
    const lon = data.city.coord.lon;

    safelySetText("sunriseValue", new Date(data.city.sunrise * 1000).toLocaleTimeString());
    safelySetText("sunsetValue", new Date(data.city.sunset * 1000).toLocaleTimeString());
    safelySetText('cityName', data.city.name);
    safelySetText('weatherDescription', data.list[0].weather[0].description);
    safelySetText('temperature', `${Math.round(data.list[0].main.temp)}°C`);

    const img = document.getElementById("weather-img");
    if (img) {
        img.src = `https://openweathermap.org/img/wn/${data.list[0].weather[0].icon}@2x.png`;
        img.style.display = "inline-block";
    }

    updateGlobeMarker(lat, lon, city);
    moveGlobeTo(lat, lon);
    const uv = await fetchUV(lat, lon);
    updateDaylight(lat, lon);
    await fetchAQI(lat, lon);
    updateInsightCards(data.list[0], aqiValueGlobal, uv);
    updateForecastUI(data.list);
}

function safelySetText(id, value) {
    const el = document.getElementById(id);
    if (el) el.innerText = value;
}

async function fetchAQI(lat, lon) {
    try {
        const res = await fetch(`https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${openWeatherKey}`);
        const data = await res.json();
        const aqi = data.list[0].main.aqi;
        aqiValueGlobal = aqi;
    } catch (err) {
        console.log("Error fetching AQI:", err);
    }
}

async function fetchUV(lat, lon) {
    try {
        const res = await fetch(`https://api.openuv.io/api/v1/uv?lat=${lat}&lng=${lon}`, {
            headers: { 'x-access-token': openUV }
        });
        const data = await res.json();
        return data.result.uv;
    } catch (err) {
        console.log("Error fetching UV:", err);
        return 0;
    }
}

function togglePopup(id) {
    const popup = document.getElementById(id);
    if (popup) {
        popup.style.display = popup.style.display === 'block' ? 'none' : 'block';
    }
}

function updateDaylight(lat, lon) {
    fetch(`https://timeapi.io/api/time/current/coordinate?latitude=${lat}&longitude=${lon}`)
        .then(res => res.json())
        .then(time => {
            const hours = time.hour;
            safelySetText('dayEmoji', (hours >= 6 && hours <= 18) ? '🌞' : '🌙');
        });
}

function initGlobe() {
    const container = document.getElementById('globeContainer');
    const scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(75, container.offsetWidth / container.offsetHeight, 0.1, 1000);
    camera.position.z = 200;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.offsetWidth, container.offsetHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    Globe = new ThreeGlobe()
        .globeImageUrl('//unpkg.com/three-globe/example/img/earth-blue-marble.jpg')
        .bumpImageUrl('//unpkg.com/three-globe/example/img/earth-topology.png')
        .showAtmosphere(false)
        .atmosphereColor('#3a228a')
        .atmosphereAltitude(0.25);

    globeGroup.add(Globe);
    scene.add(globeGroup);

    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
    directionalLight.position.set(200, 100, 300);
    scene.add(directionalLight);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.5;
    controls.enableZoom = true;

    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    animate();

    window.addEventListener('resize', () => {
        camera.aspect = container.offsetWidth / container.offsetHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.offsetWidth, container.offsetHeight);
    });
}

function updateGlobeMarker(lat, lon, name) {
    globeMarkers.length = 0;
    globeMarkers.push({ lat: lat, lng: lon, size: 1, color: 'red' });

    Globe.pointsData(globeMarkers)
        .pointAltitude('size')
        .pointColor('color')
        .pointRadius(0.5)
        .pointResolution(12);
}

function moveGlobeTo(lat, lon) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lon + 180) * (Math.PI / 180);
    controls.autoRotate = false;
    globeGroup.rotation.y = theta;
    globeGroup.rotation.x = phi - Math.PI / 2;
}

function getAQILabel(aqi) {
    if (aqi <= 50) return "Good";
    if (aqi <= 100) return "Moderate";
    if (aqi <= 150) return "Unhealthy for Sensitive";
    if (aqi <= 200) return "Unhealthy";
    if (aqi <= 300) return "Very Unhealthy";
    return "Hazardous";
}

function updateInsightCards(weather, aqi, uv) {
    const temp = weather.main.temp;
    const feels = weather.main.feels_like;
    const rain = weather.rain?.['3h'] || 0;
    const humidity = weather.main.humidity;
    const wind = weather.wind.speed;
    const visibility = weather.visibility;

    document.getElementById("tempValue").innerText = `${Math.round(temp)}°C`;
    document.getElementById("tempSuggestion").innerText =
        temp >= 38 ? "Extremely hot. Stay indoors and hydrate frequently." :
        temp >= 30 ? "Hot day ahead. Wear light clothing and drink water." :
        temp >= 20 ? "Pleasant weather. Enjoy outdoor activities!" :
        "Chilly temperatures. Carry a jacket or sweater.";

    document.getElementById("rainValue").innerText = `${rain} mm`;
    document.getElementById("rainSuggestion").innerText =
        rain > 5 ? "Heavy rainfall expected. Take precautions and carry rain gear." :
        rain > 0 ? "Light showers possible. Keep an umbrella handy." :
        "Clear skies. No rain forecasted today.";

    const aqiLabel = getAQILabel(aqi);
    document.getElementById("aqiValue").innerText = `${aqi} (${aqiLabel})`;
    document.getElementById("aqiSuggestion").innerText =
        aqi <= 50 ? "Air quality is excellent. Great day for outdoor activities." :
        aqi <= 100 ? "Moderate air quality. Safe for most people." :
        aqi <= 150 ? "Sensitive groups should limit prolonged outdoor exertion." :
        aqi <= 200 ? "Unhealthy air. Consider staying indoors." :
        "Very unhealthy. Use masks and avoid going out.";

    document.getElementById("uvValue").innerText = uv;
    document.getElementById("uvSuggestion").innerText =
        uv < 3 ? "Low UV risk. Minimal protection needed." :
        uv < 6 ? "Moderate UV. Wear sunglasses and sunscreen." :
        uv < 8 ? "High UV index. Avoid mid-day sun exposure." :
        "Very high UV! Use SPF 30+, wear a hat, and seek shade.";

    document.getElementById("windValue").innerText = `${wind} km/h`;
    document.getElementById("windSuggestion").innerText =
        wind >= 40 ? "Strong winds expected. Secure outdoor objects." :
        wind >= 20 ? "Moderately windy. Watch for flying debris." :
        "Mild wind. Comfortable breeze today.";

    document.getElementById("humidityValue").innerText = `${humidity}%`;
    document.getElementById("humiditySuggestion").innerText =
        humidity >= 80 ? "Very humid — may feel warmer than actual temperature." :
        humidity >= 50 ? "Moderate humidity. Slight stickiness possible." :
        "Dry conditions. Perfect for outdoor plans.";

    document.getElementById("visibilityValue").innerText = `${visibility} m`;
    document.getElementById("visibilitySuggestion").innerText =
        visibility < 1000 ? "Low visibility. Drive carefully and avoid travel if possible." :
        visibility < 5000 ? "Moderate visibility. Stay alert while commuting." :
        "Clear visibility. Great for travel and sightseeing.";

    document.getElementById("feelsLikeValue").innerText = `${Math.round(feels)}°C`;
    document.getElementById("feelsLikeSuggestion").innerText =
        Math.abs(feels - temp) >= 4 ? "It feels noticeably different than actual temp. Dress accordingly." :
        "Feels just like the temperature. No surprises today.";

    document.getElementById("sunriseSuggestion").innerText = "Catch the sunrise for a peaceful start to your day.";
    document.getElementById("sunsetSuggestion").innerText = "Enjoy the sunset. Great time for a walk or break.";
}

function updateForecastUI(dataList) {
    const hourlyEl = document.getElementById("hourlyData");
    const dailyEl = document.getElementById("dailyData");
    hourlyEl.innerHTML = "";
    dailyEl.innerHTML = "";

    // HOURLY FORECAST (next 12 slots, 3-hour interval)
    for (let i = 0; i < 12; i++) {
        const item = dataList[i];
        const date = new Date(item.dt * 1000);
        const day = date.getDate();
        const label = i === 0 ? `${day}, Now` : `${day}, ${date.toLocaleTimeString([], { hour: '2-digit', hour12: true })}`;

        const card = document.createElement("div");
        card.className = "forecast-card";
        card.innerHTML = `
            <div><strong>${label}</strong></div>
            <img src="https://openweathermap.org/img/wn/${item.weather[0].icon}.png" />
            <div>${Math.round(item.main.temp)}°</div>
            <div>${item.weather[0].description}</div>
            <div>Feels like: ${Math.round(item.main.feels_like)}°</div>
            <div>💧 ${item.main.humidity}%</div>
            <div>💨 ${item.wind.speed.toFixed(2)} km/h</div>
        `;
        hourlyEl.appendChild(card);
    }

    // DAILY FORECAST (grouped by day)
    const dailyMap = {};
    dataList.forEach(item => {
        const date = new Date(item.dt_txt).toLocaleDateString();
        if (!dailyMap[date]) dailyMap[date] = [];
        dailyMap[date].push(item);
    });

    Object.entries(dailyMap).slice(0, 7).forEach(([dateStr, entries]) => {
        const dateObj = new Date(entries[0].dt * 1000);
        const dayName = dateObj.toLocaleDateString(undefined, { weekday: 'long' });
        const icon = entries[Math.floor(entries.length / 2)].weather[0].icon;
        const description = entries[Math.floor(entries.length / 2)].weather[0].description;

        const avgTemp = Math.round(entries.reduce((sum, e) => sum + e.main.temp, 0) / entries.length);
        const avgFeels = Math.round(entries.reduce((sum, e) => sum + e.main.feels_like, 0) / entries.length);
        const avgHumidity = Math.round(entries.reduce((sum, e) => sum + e.main.humidity, 0) / entries.length);
        const avgWind = (entries.reduce((sum, e) => sum + e.wind.speed, 0) / entries.length).toFixed(2);

        const card = document.createElement("div");
        card.className = "forecast-card-wide";
        card.innerHTML = `
            <div><strong>${dayName}</strong></div>
            <div>${dateStr}</div>
            <img src="https://openweathermap.org/img/wn/${icon}.png" />
            <div>${avgTemp}°</div>
            <div>${description}</div>
            <div>Feels like: ${avgFeels}°</div>
            <div>💧 ${avgHumidity}%</div>
            <div>💨 ${avgWind} km/h</div>
        `;
        dailyEl.appendChild(card);
    });
}
