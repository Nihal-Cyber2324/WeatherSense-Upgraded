const apiKey = "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";  // Your API key

// Send user message to OpenAI and display the response
async function sendChat() {
  const inputField = document.getElementById("chatInput");
  const chatWindow = document.getElementById("chatWindow");
  const userMessage = inputField.value.trim();

  if (!userMessage) return;

  // Add user message to chat window
  chatWindow.innerHTML += `<div class="user-msg">${userMessage}</div>`;
  inputField.value = "";
  chatWindow.scrollTop = chatWindow.scrollHeight;

  // Show loading message
  chatWindow.innerHTML += `<div class="bot-msg">⏳ Thinking...</div>`;
  chatWindow.scrollTop = chatWindow.scrollHeight;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are a helpful and friendly climate education assistant for 11-14 year old students. Answer their questions about climate change, carbon footprint, saving energy, water conservation, pollution, and eco-friendly actions. Structure your answers clearly with bold headings (**like this**) and short easy paragraphs. Use bullet points if helpful."
          },
          {
            role: "user",
            content: userMessage
          }
        ],
        max_tokens: 500,
        temperature: 0.6
      })
    });

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "No response received.";

    // Format response with bold headings and line breaks
    const formattedReply = reply
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")   // Convert **Heading** to bold
      .replace(/\n\n/g, "<br><br>")                       // Double newline → extra space
      .replace(/\n/g, "<br>");                            // Single newline → line break

    // Replace loading message with actual reply
    const allMessages = chatWindow.querySelectorAll(".bot-msg");
    allMessages[allMessages.length - 1].innerHTML = formattedReply;

    chatWindow.scrollTop = chatWindow.scrollHeight;
  } catch (err) {
    console.error("Chatbot API Error:", err);
    const allMessages = chatWindow.querySelectorAll(".bot-msg");
    allMessages[allMessages.length - 1].innerHTML = "❌ Error fetching response. Please try again later.";
  }
}
