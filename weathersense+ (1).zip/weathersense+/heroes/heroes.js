const nationalHeroes = [
  { image: '../images/thimakka.jpg', description: `<strong>Salumarada Thimmakka:</strong> Salumarada Thimmakka, often called the "Mother of Trees," is an environmentalist from Karnataka, India. Despite facing poverty and having no formal education, she embarked on a life-changing mission to plant trees along the highways of Hulikal village. Along with her late husband, she began planting banyan trees during the drought years to provide shade and improve the ecosystem. Over her lifetime, she has planted more than 8,000 trees and nurtured them like her own children.<br><br>Her work led to the creation of green corridors that have reduced soil erosion, provided shelter for wildlife, and improved the lives of villagers and travelers alike. Thimmakka's commitment to environmental conservation has earned her numerous accolades, including the Padma Shri and the Nari Shakti Puraskar. Today, her life story is taught in schools as an example of perseverance, dedication, and the power of individual action to bring about ecological change.` },

  { image: '../images/jadhav.jpg', description: `<strong>Jadav Payeng:</strong> Known as the "Forest Man of India," Jadav Payeng single-handedly transformed a barren sandbar of the Brahmaputra River into a dense forest spanning over 1,360 acres. He began planting bamboo saplings in 1979 to combat soil erosion after witnessing the deaths of snakes washed ashore by floods. What started as a small initiative turned into a life’s mission.<br><br>Today, his Molai forest is home to Bengal tigers, rhinoceroses, elephants, deer, and countless bird species. Payeng has devoted his entire life to the preservation and expansion of the forest, educating people on the importance of reforestation and biodiversity conservation. His actions highlight the profound impact one person can have on restoring ecological balance and reversing environmental degradation.` },

  { image: '../images/sunderlal.jpg', description: `<strong>Sunderlal Bahuguna:</strong> Sunderlal Bahuguna was a Gandhian environmentalist who led the Chipko Movement in the Himalayan region of India. His efforts prevented large-scale deforestation by mobilizing local communities, who famously hugged trees to protect them from being felled by commercial loggers. Bahuguna believed that the preservation of forests was essential for the survival of mountain communities and the prevention of natural disasters.<br><br>He also opposed the construction of the Tehri Dam, citing environmental risks and the displacement of local populations. His activism inspired policy changes in India and strengthened the global environmental movement. Bahuguna's philosophy of non-violent resistance and sustainable living remains a cornerstone of environmental activism today.` },

  { image: '../images/medha.jpg', description: `<strong>Medha Patkar:</strong> Medha Patkar is a social activist and environmentalist who founded the Narmada Bachao Andolan (Save the Narmada Movement) to oppose the construction of large dams on the Narmada River. Her movement brought national and international attention to the displacement of tribal and rural communities, as well as the ecological damage caused by such projects.<br><br>Patkar has spent decades fighting for the rights of marginalized people, advocating for sustainable development, social justice, and environmental conservation. Her work challenges the notion of "development at any cost" and emphasizes the need for inclusive and sustainable growth that respects both people and nature.` },

  { image: '../images/vandana.jpg', description: `<strong>Dr. Vandana Shiva:</strong> Dr. Vandana Shiva is an internationally acclaimed physicist, author, and environmental activist. She founded the Navdanya movement, which promotes organic farming, biodiversity conservation, and seed sovereignty for farmers. Shiva has been a leading voice against genetically modified crops and industrial agriculture, arguing for the protection of indigenous farming knowledge and ecological farming practices.<br><br>Her work highlights the intersection of environmental sustainability, social justice, and food security. She has published numerous books and lectures globally, inspiring farmers, students, and policymakers to adopt eco-friendly agricultural practices that protect both people and the planet.` }
];

const globalHeroes = [
  { image: '../images/maathai.jpg', description: `<strong>Wangari Maathai:</strong> Wangari Maathai was a Kenyan environmentalist and political activist who founded the Green Belt Movement. She mobilized rural women to plant over 50 million trees, addressing deforestation, soil erosion, and water scarcity. Her work empowered women economically and socially, while improving the environment.<br><br>Maathai's activism extended beyond reforestation, advocating for human rights, democracy, and gender equality. Despite facing political repression, she remained steadfast in her cause, earning the Nobel Peace Prize in 2004. Her legacy lives on through the Green Belt Movement, inspiring environmental stewardship and women’s empowerment globally.` },

  { image: '../images/greta.jpg', description: `<strong>Greta Thunberg:</strong> Greta Thunberg is a Swedish climate activist who started the Fridays for Future movement. At just 15 years old, she began protesting outside the Swedish Parliament, demanding stronger climate action from her government. Her solitary protest evolved into a global youth-led movement, mobilizing millions to demand climate justice.<br><br>Thunberg's powerful speeches at international forums like the UN and World Economic Forum challenged world leaders to take immediate and drastic measures to combat climate change. Her activism emphasizes intergenerational justice and the moral obligation of today's leaders to safeguard the planet for future generations.` },

  { image: '../images/jane.jpg', description: `<strong>Jane Goodall:</strong> Jane Goodall is a renowned primatologist and conservationist whose groundbreaking work with chimpanzees in Tanzania redefined humanity’s understanding of animal intelligence and behavior. She established the Jane Goodall Institute to promote wildlife conservation and animal welfare.<br><br>Through the Roots & Shoots program, Goodall has inspired young people worldwide to engage in community service and environmental activism. Her advocacy emphasizes compassion for all living beings and the interconnectedness of ecosystems, human communities, and wildlife.` },

  { image: '../images/rachel.jpg', description: `<strong>Rachel Carson:</strong> Rachel Carson was an American marine biologist and conservationist whose book "Silent Spring" exposed the dangers of pesticides like DDT. Her meticulous research and compelling writing galvanized public awareness of chemical pollution’s impact on ecosystems and human health.<br><br>Carson’s work is credited with launching the modern environmental movement in the United States and leading to the creation of the Environmental Protection Agency (EPA). Her legacy endures in environmental policy, scientific integrity, and public advocacy for a pollution-free world.` },

  { image: '../images/bill.jpg', description: `<strong>Bill McKibben:</strong> Bill McKibben is an American environmentalist, author, and founder of 350.org, a global climate movement advocating for fossil fuel divestment and renewable energy adoption. His book "The End of Nature" was among the first to explain climate change to a general audience.<br><br>McKibben has organized some of the largest climate mobilizations in history, including global climate strikes and divestment campaigns. He emphasizes the urgency of reducing carbon emissions and transitioning to a sustainable, equitable energy system.` }
];

function createSlide(hero) {
  return `
    <div class="carousel-item">
      <div class="hero-image">
        <img src="${hero.image}" alt="Hero">
      </div>
      <div class="hero-content">
        <p>${hero.description}</p>
      </div>
    </div>
  `;
}

function loadCarousel(containerId, heroes) {
  const container = document.getElementById(containerId);
  container.innerHTML = heroes.map(hero => createSlide(hero)).join('');
  container.currentIndex = 0;
  updateCarousel(containerId);
}

function updateCarousel(containerId) {
  const container = document.getElementById(containerId);
  const items = container.querySelectorAll('.carousel-item');
  items.forEach((item, index) => {
    item.style.display = index === container.currentIndex ? 'flex' : 'none';
  });
}

function moveSlide(containerId, direction) {
  const container = document.getElementById(containerId);
  const totalItems = container.querySelectorAll('.carousel-item').length;
  container.currentIndex = (container.currentIndex + direction + totalItems) % totalItems;
  updateCarousel(containerId);
}

window.onload = () => {
  loadCarousel('nationalCarousel', nationalHeroes);
  loadCarousel('globalCarousel', globalHeroes);
};